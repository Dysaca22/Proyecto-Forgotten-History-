package principal.inventario.armas;

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.Random;
import principal.Constantes;
import principal.entes.Jugador;
import principal.inventario.Objeto;
import principal.sprites.HojaSprites;
import principal.sprites.Sprite;

public abstract class Arma extends Objeto {

    public static HojaSprites hojaArmas = new HojaSprites(Constantes.RUTA_ARMAS, 32, false);

    protected int ataqueMin;
    protected int ataqueMax;

    public Arma(int id, String nombre, String descripcion, int cantidad, int ataqueMin, int ataqueMax) {
        super(id, nombre, descripcion, cantidad);

        this.ataqueMin = ataqueMin;
        this.ataqueMax = ataqueMax;
    }

    public Arma(int id, String nombre, String descripcion, int ataqueMin, int ataqueMax) {
        super(id, nombre, descripcion);

        this.ataqueMin = ataqueMin;
        this.ataqueMax = ataqueMax;
    }

    public abstract ArrayList<Rectangle> getAlcance(final Jugador jugador);

    @Override
    public Sprite getSprite() {
        return hojaArmas.getSprite(id - 500);
    }

    protected int ataqueMedio(final int ataqueMinimo, final int ataqueMaximo) {
        Random r = new Random();
        return r.nextInt(ataqueMaximo - ataqueMinimo) + ataqueMinimo;
    }

}
