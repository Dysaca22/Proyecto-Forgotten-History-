package principal.entes;

import java.awt.Graphics;

public class Enemigo {

    private int id;
    private double posicionX;
    private double posicionY;
    private String nombre;
    private int vidaMaxima;
    private int vidaActual;

    public Enemigo(int id, String nombre, int vidaMaxima) {
        this.id = id;
        this.nombre = nombre;
        this.vidaMaxima = vidaMaxima;
        this.vidaActual = vidaMaxima;
        this.posicionX = 0;
        this.posicionY = 0;
    }

    public void actualizar() {

    }

    public void dibujar(final Graphics g, final int puntoX, final int puntoY) {

    }

    public void setPosicion(final int posicionX, final int posicionY) {
        this.posicionX = posicionX;
        this.posicionY = posicionY;
    }

    public double getPosicionX() {
        return posicionX;
    }

    public double getPosicionY() {
        return posicionY;
    }

    public int getId() {
        return id;
    }

    public int getVidaActual() {
        return vidaActual;
    }

}
