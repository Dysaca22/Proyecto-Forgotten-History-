package principal.entes;

import java.awt.Graphics;
import principal.Constantes;
import principal.herramientas.DibujoOpciones;
import principal.sprites.HojaSprites;

public class Zombie extends Enemigo {

    private static HojaSprites hojaZombie;

    public Zombie(int id, String nombre, int vidaMaxima) {
        super(id, nombre, vidaMaxima);

        if (hojaZombie == null) {
            hojaZombie = new HojaSprites(Constantes.RUTA_ZOMBIE + id + ".png", Constantes.LADO_SPRITE, false);
        }
    }

    @Override
    public void dibujar(final Graphics g, final int puntoX, final int puntoY) {
        DibujoOpciones.dibujarImagen(g, hojaZombie.getSprite(0).getImagen(), puntoX, puntoY);
        super.dibujar(g, puntoX, puntoY);
    }

}
